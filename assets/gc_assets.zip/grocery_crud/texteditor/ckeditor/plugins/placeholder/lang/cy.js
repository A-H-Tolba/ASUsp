﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','cy',{placeholder:{title:"Priodweddau'r Daliwr Geiriau",toolbar:'Creu Daliwr Geiriau',text:'Testun y Daliwr Geiriau',edit:"Golygu'r Dailwr Geiriau",textMissing:"Mae'n rhaid i'r daliwr geiriau gynnwys testun."}});
